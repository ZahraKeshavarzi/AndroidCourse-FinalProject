package com.example.myapplication.sharedComponents.db

object Constants {
    const val FAVORITE_MOVIE_TABLE = "favorite_movie_table"
    const val FAVORITE_MOVIE_DATABASE = "favorite_movie_database"
}