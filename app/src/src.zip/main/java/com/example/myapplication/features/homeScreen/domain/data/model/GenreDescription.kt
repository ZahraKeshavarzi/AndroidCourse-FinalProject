package com.example.myapplication.features.homeScreen.domain.data.model

data class GenreDescription(
    val en: String,
    val fa: String
)
