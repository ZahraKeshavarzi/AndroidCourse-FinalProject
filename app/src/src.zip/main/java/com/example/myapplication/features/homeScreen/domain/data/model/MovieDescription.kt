package com.example.myapplication.features.homeScreen.domain.data.model

data class MovieDescription(
    val en: String,
    val fa: String
)
