//package com.example.myapplication.sharedComponents.db
//
//import android.graphics.Bitmap
//import androidx.room.Entity
//import androidx.room.PrimaryKey
//
//@Entity(tableName = Constants.FAVORITE_MOVIE_TABLE)
//data class FavoriteMoviesEntity (
//    @PrimaryKey(autoGenerate = true)
//    val userID: Int,
//    val name: String,
//    val rate: Int,
//    val year: Int,
//    val country: String,
//    val image: Bitmap,
//    val timestamp: Long = System.currentTimeMillis()
//)