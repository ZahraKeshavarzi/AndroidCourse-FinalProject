package com.example.myapplication.features.registerScreen.domain.data

object Constants {
    const val SHARED_PREFERENCE_KEY = "shared_preference_key"
    const val USER_TOKEN_KEY = "user_token_key"
    const val DATA_EMPTY_ERROR = "please fill out all the fields!"
}