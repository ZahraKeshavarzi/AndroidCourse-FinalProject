package com.example.myapplication.features.detailsScreen.domain.data.model

data class MovieDetailsResponse(
    val data: MovieDetailsData,
    val status: Int
)
