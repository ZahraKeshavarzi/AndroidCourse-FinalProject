package com.example.myapplication.features.homeScreen.domain.data.model

data class Genre(
    val genreName: String
)
